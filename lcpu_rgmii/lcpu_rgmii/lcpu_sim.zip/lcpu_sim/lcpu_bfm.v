`timescale 1ns / 1ns

module lcpu_bfm #(
    parameter delay_time = 1000
) (
    input  logic        clk,
    input  logic        reset_l,
    input  logic        OP_DONE,
    input  logic [31:0] RD_DATA,
    output logic [31:0] ADDRESS,
    output logic [31:0] WR_DATA,
    output logic        RH_WL,
    output logic        EXEC
);

    integer file, matched, code;
    reg [31:0] temp_addr, temp_data;

    initial begin
        file = $fopen("read.tcl", "r");
        if (file == 0) file = $fopen("lcpu_sim/read.tcl", "r");
        if (file == 0) file = $fopen("/home/huamingh/work/FPGA_Prj/test/lcpu_rgmii/lcpu_sim/read.tcl", "r");
        if (file == 0) begin
            $display("BFM: Error opening read.tcl");
            $finish;
        end

        ADDRESS = 0; WR_DATA = 0; RH_WL = 1; EXEC = 0;
        #delay_time;
        $display("BFM: reading commands...");

        while (!$feof(file)) begin
            code = $fgetc(file);
            // skip whitespace and comments
            while ((code == 32 || code == 9 || code == 10 || code == 13 || code == 35) && code != -1) begin
                if (code == 35) while (code != 10 && code != 13 && code != -1) code = $fgetc(file);
                code = $fgetc(file);
            end
            if (code == -1) begin
                // EOF
            end else if (code == 106) begin  // 'j'
                code = $ungetc(code, file);
                code = $fgetc(file);  // j
                code = $fgetc(file);  // r or w
                if (code == 114) begin  // jread
                    code = $fgetc(file); code = $fgetc(file); code = $fgetc(file); // ead
                    matched = $fscanf(file, "%h", temp_addr);
                    if (matched == 1) begin
                        $display("BFM: jread 0x%h", temp_addr);
                        @(posedge clk);
                        ADDRESS = temp_addr; RH_WL = 1; EXEC = 1;
                        wait(OP_DONE);
                        @(posedge clk); EXEC = 0;
                        $display("BFM:   -> 0x%h", RD_DATA);
                    end
                end else begin  // jwrite
                    code = $fgetc(file); code = $fgetc(file); code = $fgetc(file); code = $fgetc(file); // rite
                    matched = $fscanf(file, "%h %h", temp_addr, temp_data);
                    if (matched >= 2) begin
                        $display("BFM: jwrite 0x%h 0x%h", temp_addr, temp_data);
                        @(posedge clk);
                        ADDRESS = temp_addr; WR_DATA = temp_data; RH_WL = 0; EXEC = 1;
                        wait(OP_DONE);
                        @(posedge clk); EXEC = 0;
                    end
                end
            end else begin
                while (code != 10 && code != 13 && code != -1) code = $fgetc(file);
            end
        end

        $fclose(file);
        $display("BFM: done.");
    end

endmodule
