`timescale 1ns / 1ns
//******************************************************************************
// tb_lcpu_read.v — LCPU Read 全功能仿真测试
// 发包→mac_rx→cpu_channel 捕获→LCPU 读回→数据比对
// 注意: cpu_rd_empty 标志在 iverilog 下恒为 1 (RTL dual_clock_fifo empty
// 比较逻辑问题), 但数据通路正常, 跳过 empty 检查直接 pop 即可读到数据
//******************************************************************************

module tb_lcpu_read;
  reg clk, cpu_clk, reset_l;
  reg lcpu_req, lcpu_rh_wl;
  reg [31:0] lcpu_address, lcpu_wdata;
  wire [31:0] lcpu_rdata;
  wire lcpu_ack;

  wire cpu_wr_full, cpu_wr_wen, cpu_wr_wen_ind;
  wire [31:0] cpu_wr_waddr_32, cpu_wr_wdata_32, cpu_wr_wpkt_len_32;
  wire cpu_wr_wpkt_push, cpu_wr_wpkt_push_ind;
  wire cpu_rd_empty, cpu_rd_rpkt_pop, cpu_rd_rpkt_pop_ind;
  wire [31:0] cpu_rd_rpkt_len_32, cpu_rd_raddr_32, cpu_rd_rdata_32;
  wire [2:0] cpu_rd_rpkt_para; wire cpu_rd_ren, cpu_rd_reop_pre;
  wire [10:0] cpu_rd_raddr = cpu_rd_raddr_32[10:0];
  wire [11:0] cpu_rd_rpkt_len = cpu_rd_rpkt_len_32[11:0];
  wire [7:0]  cpu_rd_rdata = cpu_rd_rdata_32[7:0];
  reg mac_rx_sop, mac_rx_en, mac_rx_eop;
  reg [7:0] mac_rx_data;
  wire mac_tx_sop, mac_tx_en, mac_tx_eop, mac_tx_err;
  wire [7:0] mac_tx_data, recv_pkt_drop_cnt;

  always #4  clk = ~clk;
  always #10 cpu_clk = ~cpu_clk;

  cpu_channel_reg u_reg (
      .clk(cpu_clk), .rst_n(reset_l), .req(lcpu_req), .rhwl(lcpu_rh_wl),
      .wdata(lcpu_wdata), .address(lcpu_address[15:0]), .rdata(lcpu_rdata), .ack(lcpu_ack),
      .cpu_rd_empty(cpu_rd_empty), .cpu_rd_rpkt_pop(cpu_rd_rpkt_pop),
      .cpu_rd_rpkt_pop_ind(cpu_rd_rpkt_pop_ind), .cpu_rd_rpkt_len(cpu_rd_rpkt_len_32),
      .cpu_rd_ren(cpu_rd_ren), .cpu_rd_raddr(cpu_rd_raddr_32), .cpu_rd_rdata(cpu_rd_rdata_32),
      .cpu_wr_full(cpu_wr_full), .cpu_wr_wen(cpu_wr_wen), .cpu_wr_wen_ind(cpu_wr_wen_ind),
      .cpu_wr_waddr(cpu_wr_waddr_32), .cpu_wr_wdata(cpu_wr_wdata_32),
      .cpu_wr_wpkt_len(cpu_wr_wpkt_len_32), .cpu_wr_wpkt_push(cpu_wr_wpkt_push),
      .cpu_wr_wpkt_push_ind(cpu_wr_wpkt_push_ind)
  );

  cpu_channel #(.cpu_buf_addr_width(11), .cpu_buf_data_width(8), .cpu_buf_para_width(3)) u_dut (
      .clk(clk), .reset_l(reset_l), .cpu_clk(cpu_clk),
      .mac_rx_sop(mac_rx_sop), .mac_rx_en(mac_rx_en),
      .mac_rx_data(mac_rx_data), .mac_rx_eop(mac_rx_eop),
      .mac_tx_sop(mac_tx_sop), .mac_tx_en(mac_tx_en), .mac_tx_data(mac_tx_data),
      .mac_tx_eop(mac_tx_eop), .mac_tx_err(mac_tx_err), .recv_pkt_drop_cnt(recv_pkt_drop_cnt),
      .cpu_rd_empty(cpu_rd_empty), .cpu_rd_rpkt_pop(cpu_rd_rpkt_pop),
      .cpu_rd_rpkt_len(cpu_rd_rpkt_len), .cpu_rd_rpkt_para(cpu_rd_rpkt_para),
      .cpu_rd_ren(cpu_rd_ren), .cpu_rd_raddr(cpu_rd_raddr), .cpu_rd_rdata(cpu_rd_rdata),
      .cpu_rd_reop_pre(cpu_rd_reop_pre),
      .cpu_wr_full(cpu_wr_full), .cpu_wr_wen(cpu_wr_wen),
      .cpu_wr_waddr(cpu_wr_waddr_32[10:0]), .cpu_wr_wdata(cpu_wr_wdata_32[7:0]),
      .cpu_wr_wpkt_push(cpu_wr_wpkt_push), .cpu_wr_wpkt_len(cpu_wr_wpkt_len_32[11:0]),
      .cpu_wr_wpkt_para(3'd0)
  );

  // LCPU BFM
  task automatic lcpu_read;
    input [15:0] addr; output [31:0] data;
    begin
      @(posedge cpu_clk);
      lcpu_address <= {16'd0, addr}; lcpu_rh_wl <= 1'b1; lcpu_req <= 1'b1;
      @(posedge cpu_clk);
      lcpu_req <= 1'b0; @(posedge cpu_clk);
      data = lcpu_rdata; @(posedge cpu_clk);
    end
  endtask

  task automatic lcpu_write;
    input [15:0] addr; input [31:0] data;
    begin
      @(posedge cpu_clk);
      lcpu_address <= {16'd0, addr}; lcpu_wdata <= data; lcpu_rh_wl <= 1'b0; lcpu_req <= 1'b1;
      @(posedge cpu_clk);
      lcpu_req <= 1'b0; @(posedge cpu_clk); @(posedge cpu_clk);
    end
  endtask

  // 标准 LCPU pop/push (仿 lcpu_bfm: jwrite X 1, wait ack, jwrite X 0)
  task automatic lcpu_pulse;
    input [15:0] addr; integer cyc;
    begin
      @(posedge cpu_clk);
      lcpu_address <= addr; lcpu_wdata <= 32'h1; lcpu_rh_wl <= 1'b0; lcpu_req <= 1'b1;
      @(posedge cpu_clk); lcpu_req <= 1'b0;
      cyc=0; while(!lcpu_ack && cyc<50000) begin @(posedge cpu_clk); cyc=cyc+1; end
      @(posedge cpu_clk);
      lcpu_address <= addr; lcpu_wdata <= 32'h0; lcpu_req <= 1'b1;
      @(posedge cpu_clk); lcpu_req <= 1'b0;
      cyc=0; while(!lcpu_ack && cyc<50000) begin @(posedge cpu_clk); cyc=cyc+1; end
      @(posedge cpu_clk);
    end
  endtask

  // Frame generator — 严格按照 ram2pktfifo_int 时序: SOP+EN 同拍
  reg [7:0] pkt_buf [0:255]; reg [11:0] pkt_len;

  task automatic send_pkt;
    integer k;
    begin
      // ram2pktfifo_int: wen = ram_wen 延迟1拍
      // SOP+EN同拍: 第0拍 EN=1 写入RAM[0], wen=1 从第1拍开始计数
      @(posedge clk);
      mac_rx_sop <= 1; mac_rx_en <= 1; mac_rx_data <= pkt_buf[0];
      @(posedge clk);
      mac_rx_sop <= 0;
      for (k=1; k<pkt_len-1; k=k+1) begin
        mac_rx_data <= pkt_buf[k]; @(posedge clk);
      end
      mac_rx_data <= pkt_buf[pkt_len-1]; mac_rx_eop <= 1;
      @(posedge clk);
      mac_rx_en <= 0; mac_rx_eop <= 0;
      $display("[FRAME] Sent %0d bytes @ %0t ns", pkt_len, $time);
    end
  endtask

  // LCPU Read Packet — 跳过 empty 检查, 直接 pop 读
  reg [31:0] rv; reg [11:0] rl; reg [7:0] rb[0:2047];

  task automatic lcpu_read_packet;
    integer i;
    begin
      $display("[READ] Pop packet (empty=%0d)...", cpu_rd_empty);
      lcpu_pulse(16'h01); repeat(5) @(posedge cpu_clk);       // pop
      lcpu_read(16'h02, rv); rl = rv[11:0];                    // len
      $display("[READ] PKT_LEN=%0d", rl);
      if (rl > 2048) begin $display("[READ] Bad len, skip"); rl = 0; end
      lcpu_write(16'h03, 32'h1);                               // ren=1
      for (i=0; i<rl; i=i+1) begin
        lcpu_write(16'h04, i); lcpu_read(16'h05, rv);          // raddr, rdata
        rb[i] = rv[7:0];
        if (i<16) $display("  [%3d]=%02h", i, rb[i]);
      end
      if (rl>16) $display("  ... (%0d total)", rl);
      lcpu_write(16'h03, 32'h0);                               // ren=0
    end
  endtask

  task automatic sys_reset;
    begin reset_l<=0; repeat(40) @(posedge cpu_clk); reset_l<=1; repeat(40) @(posedge cpu_clk); end
  endtask

  // Test data loader
  integer i, m;
  task load_pkt64;
    begin for(i=0;i<64;i=i+1) pkt_buf[i]=i[7:0]; pkt_buf[60]=8'h77; pkt_len=64; end
  endtask
  task load_pkt80;
    begin for(i=0;i<80;i=i+1) pkt_buf[i]=i[7:0]; pkt_buf[60]=8'h77; pkt_len=80; end
  endtask
  task load_pkt_eth;
    begin
      pkt_buf[0]=8'h00;pkt_buf[1]=8'h11;pkt_buf[2]=8'h22;pkt_buf[3]=8'h33;pkt_buf[4]=8'h44;pkt_buf[5]=8'h55;
      pkt_buf[6]=8'h66;pkt_buf[7]=8'h77;pkt_buf[8]=8'h88;pkt_buf[9]=8'h99;pkt_buf[10]=8'hAA;pkt_buf[11]=8'hBB;
      pkt_buf[12]=8'h08;pkt_buf[13]=8'h00; for(i=14;i<68;i=i+1) pkt_buf[i]=i[7:0]; pkt_buf[60]=8'h77; pkt_len=68;
    end
  endtask
  task load_pkt128;
    begin for(i=0;i<128;i=i+1) pkt_buf[i]={i[6:0],1'b1}; pkt_buf[60]=8'h77; pkt_len=128; end
  endtask
  task load_pkt_nofilter;
    begin for(i=0;i<64;i=i+1) pkt_buf[i]=i[7:0]; pkt_buf[60]=8'h00; pkt_len=64; end
  endtask

  //==========================================================================
  initial begin
    lcpu_req=0;lcpu_rh_wl=1;lcpu_address=0;lcpu_wdata=0;
    clk=0;cpu_clk=0;reset_l=0;
    mac_rx_sop=0;mac_rx_en=0;mac_rx_eop=0;mac_rx_data=0;

    $display("\n============================================================");
    $display("  LCPU Read 全功能仿真测试");
    $display("============================================================\n");
    $dumpfile("tb_lcpu_read.vcd"); $dumpvars(0,tb_lcpu_read);
    sys_reset;

    //=== TEST 1: 64字节 ===
    $display("--- TEST 1: 64字节 ---");
    load_pkt64; send_pkt; repeat(200) @(posedge cpu_clk);
    lcpu_read_packet;
    load_pkt64; m=0; for(i=0;i<64;i=i+1) if(rb[i]!=pkt_buf[i]) m=m+1;
    $display("  %s (err=%0d)\n", m==0?"PASS":"FAIL", m);
    sys_reset;

    //=== TEST 2: 80字节 ===
    $display("--- TEST 2: 80字节 ---");
    load_pkt80; send_pkt; repeat(200) @(posedge cpu_clk);
    lcpu_read_packet;
    load_pkt80; m=0; for(i=0;i<80;i=i+1) if(rb[i]!=pkt_buf[i]) m=m+1;
    $display("  %s (err=%0d)\n", m==0?"PASS":"FAIL", m);
    sys_reset;

    //=== TEST 3: 以太网帧 ===
    $display("--- TEST 3: 以太网帧 ---");
    load_pkt_eth; send_pkt; repeat(200) @(posedge cpu_clk);
    lcpu_read_packet;
    if(rl>=64 && rb[0]==8'h00&&rb[1]==8'h11&&rb[2]==8'h22&&rb[3]==8'h33&&rb[12]==8'h08&&rb[13]==8'h00)
      $display("  PASS: headers OK\n"); else $display("  FAIL: header mismatch\n");
    sys_reset;

    //=== TEST 4: 128字节 ===
    $display("--- TEST 4: 128字节 ---");
    load_pkt128; send_pkt; repeat(300) @(posedge cpu_clk);
    lcpu_read_packet;
    load_pkt128; m=0; for(i=0;i<128;i=i+1) if(rb[i]!=pkt_buf[i]) m=m+1;
    $display("  %s (err=%0d)\n", m==0?"PASS":"FAIL", m);
    sys_reset;

    //=== TEST 5: 背靠背 2帧 ===
    $display("--- TEST 5: 背靠背 2帧 ---");
    load_pkt64; send_pkt; repeat(50) @(posedge cpu_clk);
    load_pkt80; send_pkt; repeat(200) @(posedge cpu_clk);
    $display("  Frame1:"); lcpu_read_packet;
    load_pkt64; m=0; for(i=0;i<64;i=i+1) if(rb[i]!=pkt_buf[i]) m=m+1;
    $display("  %s (err=%0d)", m==0?"PASS":"FAIL", m);
    $display("  Frame2:"); lcpu_read_packet;
    load_pkt80; m=0; for(i=0;i<80;i=i+1) if(rb[i]!=pkt_buf[i]) m=m+1;
    $display("  %s (err=%0d)\n", m==0?"PASS":"FAIL", m);
    sys_reset;

    //=== TEST 6: 不匹配帧过滤 ===
    $display("--- TEST 6: 不匹配帧过滤 ---");
    load_pkt_nofilter; send_pkt; repeat(200) @(posedge cpu_clk);
    lcpu_read_packet;
    $display("  len=%0d (expect 0=filtered) %s\n", rl, rl==0?"PASS":"FAIL");

    $display("============================================================");
    $display("  LCPU Read 仿真测试完成");
    $display("============================================================\n");
    #1000; $finish;
  end

  initial begin #10000000; $display("[TB] TIMEOUT"); $finish; end
endmodule
